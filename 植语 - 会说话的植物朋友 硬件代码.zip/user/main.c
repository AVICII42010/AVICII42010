//单片机头文件
#include "stm32f10x.h"

//网络协议层
#include "onenet.h"

//网络设备
#include "esp8266.h"

//硬件驱动
#include "delay.h"
#include "usart.h"
#include "led.h"
#include "key.h"
#include "dht11.h"
#include "oled.h"
#include "AD.h"
#include "SGP30.h"

//C库
#include <string.h>

#define ESP8266_ONENET_INFO		"AT+CIPSTART=\"TCP\",\"mqtts.heclouds.com\",1883\r\n"

void Hardware_Init(void);
void Display_Init(void);
void Refresh_Data(void);

u32 co = 400;  //定义CO2浓度变量与TVOC浓度变量
u32 sgp30_dat;          //定义SGP30读取到的数据

u8 temp,humi,fire,smoke;
float AD0,AD1;

void Get_Co2_Num()
{
	SGP30_Write_cmd(0x20,0x08);
    sgp30_dat = SGP30_Read();                  		//读取SGP30的值
    co = (sgp30_dat & 0xffff0000) >> 16;  				//获取CO2的值
    //TVOCData = sgp30_dat & 0x0000ffff;         	//获取TVOC的值
}

int main(void)
{
	
	unsigned short timeCount = 0;	//发送间隔变量
	
	unsigned char *dataPtr = NULL;
	
	Hardware_Init();				//初始化外围硬件
	
	ESP8266_Init();					//初始化ESP8266
	AD_Init();

//	UsartPrintf(USART_DEBUG, "Connect MQTTs Server...\r\n");
	OLED_Clear(); OLED_ShowString(0,0,"Connect MQTTs Server...",16);
	while(ESP8266_SendCmd(ESP8266_ONENET_INFO, "CONNECT"))
		DelayXms(500);
//	UsartPrintf(USART_DEBUG, "Connect MQTT Server Success\r\n");
	OLED_ShowString(0,4,"Connect MQTT Server Success",16); DelayXms(500);

	OLED_Clear(); OLED_ShowString(0,0,"Device login ...",16);
	while(OneNet_DevLink())			//接入OneNET
	{
		ESP8266_SendCmd(ESP8266_ONENET_INFO, "CONNECT");
		DelayXms(500);
	}
		

	OneNET_Subscribe();
	
	Display_Init();
	while(1)
	{
		
		AD0 = 100 - ((float)AD_Value[0] / 4095 * 100);
		AD1 = 100 - ((float)AD_Value[1] / 4095 * 100);
		fire = (int)AD0;
		smoke = (int)AD1;
		
		Get_Co2_Num();
		
		if(++timeCount >= 100)									//发送间隔5s
		{
			DHT11_Read_Data(&temp,&humi);
			
//			UsartPrintf(USART_DEBUG, "OneNet_SendData\r\n");
			OneNet_SendData();									//发送数据
			
			timeCount = 0;
			ESP8266_Clear();
		}
		
		dataPtr = ESP8266_GetIPD(0);
		if(dataPtr != NULL)
			OneNet_RevPro(dataPtr);
		
		Refresh_Data();
		
		if(fire <= 30 || smoke <= 40 || temp >= 70 || humi <= 20 && humi > 0)
		{		
			Led_Set(LED_ON);
//			DelayMs(500);
//			Led_Set(LED_OFF);
//			DelayMs(500);
		}
		DelayMs(10);
	
	}

}

void Hardware_Init(void)
{
	
	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);	//中断控制器分组设置

	Delay_Init();									//systick初始化
	
	Usart1_Init(115200);							//串口1，打印信息用
	
	Usart2_Init(115200);							//串口2，驱动ESP8266用
	
	Key_Init();
	
	Led_Init();									//初始化led
	
	OLED_Init();			//初始化OLED 
  
  SGP30_Init();
	
	while(DHT11_Init())
	{
//		UsartPrintf(USART_DEBUG, "DHT11 Error \r\n");
		OLED_ShowString(0,0,"DHT11 Error",16);
		DelayMs(1000);
	}
	
//	UsartPrintf(USART_DEBUG, " Hardware init OK\r\n");
	OLED_Clear(); OLED_ShowString(0,0,"Hardware init OK",16); DelayMs(1000);
}

void Display_Init(void)
{
	
	OLED_Clear();
	OLED_ShowString(85,0,"co2:",16);
	OLED_ShowString(0,0,"temp:",16);
	OLED_ShowString(0,2,"humi:",16);
	OLED_ShowString(0,4,"illu:",16);
	OLED_ShowString(0,6,"soil:",16);
	OLED_ShowString(80,4,"led:",16);
	
}
void Refresh_Data(void)
{
	OLED_ShowNum(36,0,temp,3,16);
	OLED_ShowNum(36,2,humi,3,16);
	OLED_ShowNum(36,4,fire,3,16);
	OLED_ShowNum(44,6,smoke,3,16);
	OLED_ShowNum(70,2,co,5,16);
	
	if(led_info.Led_Status) OLED_ShowString(80,6," ON ",16);//亮
	else OLED_ShowString(88,6,"OFF",16);//灭
}
