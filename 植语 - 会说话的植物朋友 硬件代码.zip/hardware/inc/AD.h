#ifndef __AD_H__
#define __AD_H__

extern uint16_t AD_Value[2];
void AD_Init(void);
void AD_GetValue(void);



#endif
